#!/bin/sh
ulimit -s 65535
ulimit -n 65535
logname=server.log
pid=`ps -ef | grep xs.jar | grep -v grep | awk '{print $2}'`
if [ -z $pid ]; then
	cd /xs/
	nohup java -Xmx1024M -XX:MaxGCPauseMillis=30 -jar xs.jar > $logname 2>&1  &
	echo TCPSpeed Server is running,log file /xs/$logname
sh /xs/check_activation.sh
else
echo TCPSpeed Server already running! log file /xs/$logname
fi
