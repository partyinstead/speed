#!/bin/bash
cd /xs
rm -rf xs_f1
echo "TCPSpeed activate script."
echo -n "Checking activation code..."
base="http://d.tcpspeed.com:8080/xs/active.jsp?type=submit_code&active_code="
url="${base}""$1"
wget -q -O xs_f1 $url 
cat xs_f1
rm -rf xs_f1
sh restart.sh
