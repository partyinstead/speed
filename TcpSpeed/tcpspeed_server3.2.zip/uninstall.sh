sh /xs/stop.sh
rm -rf /xs
if [ "$OS" == 'centos' ]; then
	chkconfig --del tcpspeed
else
	update-rc.d -f tcpspeed remove
fi
echo "TCPSpeed uninstall success!"