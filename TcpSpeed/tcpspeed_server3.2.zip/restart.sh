#!/bin/sh
cd /xs/
sh stop.sh
sh start.sh

