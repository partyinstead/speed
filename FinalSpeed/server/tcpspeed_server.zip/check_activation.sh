#!/bin/bash
cd /xs
rm -rf xs_f1
echo "Checking activation."
url="http://d.tcpspeed.com:8080/xs/active.jsp?type=check_active_text"
wget -q -O xs_f1 $url 
cat xs_f1
rm -rf xs_f1
